﻿namespace Instagram.Models
{
    public class Like
    {
        public int likeId { get; set; }

        public int userId { get; set; }

        public int postId { get; set; }

    }
}
