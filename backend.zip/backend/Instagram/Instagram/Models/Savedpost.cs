﻿namespace Instagram.Models
{
    public class Savedpost
    {    
        public int id { get; set; }
        public int userId { get; set; }
        public int postId { get; set; }
    }
}
